package com.qasapps.aivideorebrander.engine

import com.qasapps.aivideorebrander.data.EditPlan
import com.qasapps.aivideorebrander.data.KeepSegment
import com.qasapps.aivideorebrander.data.RebrandOptions
import com.qasapps.aivideorebrander.data.Scene

/**
 * Combines detected scenes, detected silence and the user's keep/remove
 * choices into the final list of segments that will be exported.
 */
object EditPlanner {

    private const val MIN_KEEP_US = 250_000L

    fun build(
        options: RebrandOptions,
        scenes: List<Scene>,
        silences: List<Pair<Long, Long>>,
        durationUs: Long,
        audioPeak: Float
    ): EditPlan {
        val base: List<KeepSegment> = if (options.detectScenes && scenes.isNotEmpty()) {
            scenes.filter { it.keep }.map { KeepSegment(it.startUs, it.endUs) }
        } else {
            listOf(KeepSegment(0, durationUs))
        }

        val withoutSilence = if (options.cutSilence) {
            base.flatMap { seg -> subtractSilences(seg, silences) }
        } else base

        val merged = mergeTinyGaps(withoutSilence.filter { it.endUs - it.startUs >= MIN_KEEP_US })
        return EditPlan(scenes, emptyList(), merged, audioPeak, silences)
    }

    private fun subtractSilences(
        seg: KeepSegment,
        silences: List<Pair<Long, Long>>
    ): List<KeepSegment> {
        var pieces = listOf(seg)
        for ((sStart, sEnd) in silences.sortedBy { it.first }) {
            if (sEnd <= seg.startUs || sStart >= seg.endUs) continue
            pieces = pieces.flatMap { p ->
                when {
                    sStart <= p.startUs && sEnd >= p.endUs -> emptyList()
                    sStart <= p.startUs -> listOf(KeepSegment(sEnd, p.endUs))
                    sEnd >= p.endUs -> listOf(KeepSegment(p.startUs, sStart))
                    else -> listOf(KeepSegment(p.startUs, sStart), KeepSegment(sEnd, p.endUs))
                }.filter { it.endUs > it.startUs }
            }
        }
        return pieces
    }

    private fun mergeTinyGaps(segments: List<KeepSegment>): List<KeepSegment> {
        if (segments.isEmpty()) return segments
        val sorted = segments.sortedBy { it.startUs }
        val out = mutableListOf(sorted.first())
        for (s in sorted.drop(1)) {
            val last = out.last()
            if (s.startUs - last.endUs < 150_000) {
                out[out.lastIndex] = KeepSegment(last.startUs, maxOf(last.endUs, s.endUs))
            } else out.add(s)
        }
        return out
    }
}
