package com.qasapps.aivideorebrander.data

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Editing style presets. Each preset is just a bundle of default option values —
 * the user can change every individual effect afterwards.
 */
enum class EditStyle(val title: String, val blurb: String) {
    CINEMATIC(
        "Cinematic",
        "Slow push-in zooms, warm grade, fade transitions. Best for travel & stories."
    ),
    DYNAMIC(
        "Dynamic",
        "Punchy zooms, vivid grade, snappy cuts. Best for reels & hype clips."
    ),
    CLEAN(
        "Clean",
        "Minimal changes: tidy cuts, neutral grade. Best for talking-head videos."
    ),
    SOCIAL(
        "Social Media",
        "9:16 vertical, bold captions, branded title. Best for TikTok/Reels/Shorts."
    )
}

enum class AspectRatioOption(val title: String, val w: Int, val h: Int) {
    ORIGINAL("Original", 0, 0),
    NINE_SIXTEEN("9:16", 9, 16),
    SIXTEEN_NINE("16:9", 16, 9),
    ONE_ONE("1:1", 1, 1)
}

enum class ExportQuality(val title: String, val heightPx: Int) {
    P720("720p", 720),
    P1080("1080p", 1080)
}

enum class ColorGrade(val title: String) {
    NONE("None"),
    CINEMATIC_WARM("Cinematic warm"),
    VIVID("Vivid pop"),
    NOIR("Noir (B&W)")
}

/** One detected scene (or sub-segment) of the source video. Times are microseconds. */
@Parcelize
data class Scene(
    val index: Int,
    val startUs: Long,
    val endUs: Long,
    var keep: Boolean = true
) : Parcelable {
    val durationMs: Long get() = (endUs - startUs) / 1000
}

/** One caption line. Times are microseconds, relative to the SOURCE video. */
@Parcelize
data class CaptionLine(
    var startUs: Long,
    var endUs: Long,
    var text: String
) : Parcelable

/** A final keep-segment after scenes, silence cuts and user toggles are applied. */
data class KeepSegment(val startUs: Long, val endUs: Long)

/** Everything the user chose on the options screen. */
@Parcelize
data class RebrandOptions(
    var style: EditStyle = EditStyle.DYNAMIC,
    var detectScenes: Boolean = true,
    var cutSilence: Boolean = true,
    var dynamicZoom: Boolean = true,
    var colorGrade: ColorGrade = ColorGrade.CINEMATIC_WARM,
    var transitions: Boolean = true,
    var aiCaptions: Boolean = true,
    var captionAllCaps: Boolean = true,
    var titleOverlay: String = "",
    var brandOverlay: String = "",
    var normalizeAudio: Boolean = true,
    var backgroundMusicUri: Uri? = null,
    var musicVolume: Float = 0.25f,
    var aspectRatio: AspectRatioOption = AspectRatioOption.ORIGINAL,
    var quality: ExportQuality = ExportQuality.P720
) : Parcelable {
    companion object {
        fun defaultsFor(style: EditStyle): RebrandOptions = when (style) {
            EditStyle.CINEMATIC -> RebrandOptions(
                style = style,
                colorGrade = ColorGrade.CINEMATIC_WARM,
                aiCaptions = false,
                aspectRatio = AspectRatioOption.SIXTEEN_NINE
            )
            EditStyle.DYNAMIC -> RebrandOptions(style = style)
            EditStyle.CLEAN -> RebrandOptions(
                style = style,
                dynamicZoom = false,
                colorGrade = ColorGrade.NONE,
                transitions = false,
                cutSilence = true
            )
            EditStyle.SOCIAL -> RebrandOptions(
                style = style,
                aspectRatio = AspectRatioOption.NINE_SIXTEEN,
                aiCaptions = true,
                captionAllCaps = true
            )
        }
    }
}

/** Basic metadata read from the source video. */
@Parcelize
data class VideoMeta(
    val durationUs: Long,
    val width: Int,
    val height: Int,
    val rotation: Int,
    val hasAudio: Boolean
) : Parcelable

/** The full plan produced by "Auto Re-Edit", editable by the user before export. */
data class EditPlan(
    val scenes: List<Scene>,
    val captions: List<CaptionLine>,
    val keepSegments: List<KeepSegment>,
    /** Peak audio amplitude (0..1) measured while decoding; used for normalization. */
    val audioPeak: Float,
    /** Silence intervals removed by the planner (kept so the plan can be rebuilt). */
    val silences: List<Pair<Long, Long>> = emptyList()
)
