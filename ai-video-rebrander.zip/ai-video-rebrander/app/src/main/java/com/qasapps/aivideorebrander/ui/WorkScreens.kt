package com.qasapps.aivideorebrander.ui

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.qasapps.aivideorebrander.RebrandViewModel
import com.qasapps.aivideorebrander.engine.EditPlanner
import com.qasapps.aivideorebrander.engine.ExportHub
import com.qasapps.aivideorebrander.engine.ExportService
import com.qasapps.aivideorebrander.engine.ExportState
import kotlinx.coroutines.launch

// ------------------------------------------------------------ processing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProcessingScreen(vm: RebrandViewModel, nav: NavController) {
    val context = LocalContext.current
    val state by ExportHub.state.collectAsState()

    LaunchedEffect(state) {
        if (state is ExportState.Done) {
            nav.navigate("preview") { popUpTo("processing") { inclusive = true } }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Re-editing your video") }) }) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            when (val s = state) {
                is ExportState.Running -> {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(24.dp))
                    Text(s.stage, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { s.progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("${(s.progress * 100).toInt()}%")
                    Spacer(Modifier.height(32.dp))
                    OutlinedButton(onClick = {
                        ExportService.cancel(context)
                        nav.popBackStack()
                    }) { Text("Cancel") }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "You can leave the app — the export keeps running.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is ExportState.Error -> {
                    Text("Something went wrong", fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(s.message, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { nav.popBackStack() }) { Text("Back to options") }
                }
                is ExportState.Cancelled -> {
                    Text("Export cancelled.")
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { nav.popBackStack() }) { Text("Back to options") }
                }
                else -> {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(16.dp))
                    Text("Starting…")
                }
            }
        }
    }
}

// ------------------------------------------------------------ preview

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(vm: RebrandViewModel, nav: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val state by ExportHub.state.collectAsState()

    val session = ExportHub.session
    val basePlan = ExportHub.plan
    if (session == null || basePlan == null) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("No export to preview yet.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = { nav.popBackStack() }) { Text("Back") }
        }
        return
    }

    val outputFile = session.outputFile
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(outputFile)))
            prepare()
        }
    }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }
    // Replay the file after every re-export (same path, new content).
    LaunchedEffect(state) {
        if (state is ExportState.Done) {
            player.setMediaItem(MediaItem.fromUri(Uri.fromFile(outputFile)))
            player.prepare()
            player.play()
        }
    }

    // Editable copies of the plan.
    val scenes = remember(basePlan) {
        mutableStateListOf(*basePlan.scenes.map { it.copy() }.toTypedArray())
    }
    val captions = remember(basePlan) {
        mutableStateListOf(*basePlan.captions.map { it.copy() }.toTypedArray())
    }
    var titleText by remember(basePlan) { mutableStateOf(vm.options.titleOverlay) }
    var brandText by remember(basePlan) { mutableStateOf(vm.options.brandOverlay) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun rebuildPlan() =
        EditPlanner.build(
            vm.options, scenes, basePlan.silences,
            session.meta.durationUs, basePlan.audioPeak
        ).copy(captions = captions.toList())

    Scaffold(
        topBar = { TopAppBar(title = { Text("Preview & adjust") }) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )

            if (state is ExportState.Running) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text((state as ExportState.Running).stage,
                    style = MaterialTheme.typography.bodySmall)
            }
            (state as? ExportState.Error)?.let {
                Text(it.message, color = MaterialTheme.colorScheme.error)
            }
            errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            ExportHub.lastNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Text("Scenes — uncheck to drop", fontWeight = FontWeight.Bold)
            if (scenes.isEmpty()) {
                Text("Single continuous clip (scene detection off or no cuts found).",
                    style = MaterialTheme.typography.bodySmall)
            }
            scenes.forEachIndexed { i, scene ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = scene.keep,
                        onCheckedChange = { scenes[i] = scene.copy(keep = it) }
                    )
                    Text(
                        "Scene ${scene.index + 1} • " +
                            "${fmt(scene.startUs)}–${fmt(scene.endUs)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            if (captions.isNotEmpty()) {
                Text("Captions — tap to edit", fontWeight = FontWeight.Bold)
                captions.forEachIndexed { i, line ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt(line.startUs),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.width(52.dp))
                        OutlinedTextField(
                            value = line.text,
                            onValueChange = { captions[i] = line.copy(text = it) },
                            modifier = Modifier.weight(1f),
                            singleLine = false, maxLines = 2
                        )
                    }
                }
            }

            Text("Text overlays", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = titleText,
                onValueChange = {
                    titleText = it
                    vm.options = vm.options.copy(titleOverlay = it)
                },
                label = { Text("Title card") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                value = brandText,
                onValueChange = {
                    brandText = it
                    vm.options = vm.options.copy(brandOverlay = it)
                },
                label = { Text("Watermark / handle") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = {
                        ExportHub.plan = rebuildPlan()
                        errorMsg = null
                        ExportService.reexport(context)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    androidx.compose.material3.Icon(
                        Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Re-export")
                }
                Button(
                    onClick = {
                        scope.launch {
                            vm.saveToGallery(context, outputFile)
                                .onSuccess {
                                    snackbar.showSnackbar(
                                        "Saved to Movies / AI Video Rebrander")
                                }
                                .onFailure {
                                    errorMsg = "Save failed: ${it.message}"
                                }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    androidx.compose.material3.Icon(
                        Icons.Default.Save, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save to phone")
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun fmt(us: Long): String {
    val s = us / 1_000_000
    return "${s / 60}:${"%02d".format(s % 60)}"
}
