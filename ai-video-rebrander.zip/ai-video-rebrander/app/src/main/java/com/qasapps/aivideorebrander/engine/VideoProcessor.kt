package com.qasapps.aivideorebrander.engine

import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.effect.Contrast
import androidx.media3.effect.Crop
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.qasapps.aivideorebrander.data.AspectRatioOption
import com.qasapps.aivideorebrander.data.CaptionLine
import com.qasapps.aivideorebrander.data.ColorGrade
import com.qasapps.aivideorebrander.data.EditPlan
import com.qasapps.aivideorebrander.data.KeepSegment
import com.qasapps.aivideorebrander.data.RebrandOptions
import com.qasapps.aivideorebrander.data.VideoMeta
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/** Reads basic metadata from a video Uri. */
object VideoMetaReader {
    fun read(context: Context, uri: Uri): VideoMeta {
        val r = MediaMetadataRetriever()
        r.setDataSource(context, uri)
        try {
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
            return VideoMeta(durMs * 1000, w, h, rot, hasAudioTrack(context, uri))
        } finally {
            r.release()
        }
    }

    private fun hasAudioTrack(context: Context, uri: Uri): Boolean {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(context, uri, null)
            (0 until ex.trackCount).any {
                (ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME) ?: "")
                    .startsWith("audio/")
            }
        } catch (_: Exception) {
            false
        } finally {
            ex.release()
        }
    }
}

/** Simple linear-gain audio processor used for loudness normalization. */
class GainAudioProcessor(private val gain: Float) : AudioProcessor {
    private var active = false
    private var ended = false
    private var output = ByteBuffer.allocate(0)

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        active = gain != 1f && inputAudioFormat.encoding == C.ENCODING_PCM_16BIT
        return inputAudioFormat
    }

    override fun isActive(): Boolean = active

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!active) return
        val dup = inputBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val out = ByteBuffer.allocateDirect(dup.remaining()).order(ByteOrder.LITTLE_ENDIAN)
        while (dup.remaining() >= 2) {
            val s = dup.short
            val v = (s * gain).roundToInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            out.putShort(v)
        }
        out.flip()
        output = out
        inputBuffer.position(inputBuffer.limit()) // consumed
    }

    override fun queueEndOfStream() {
        ended = true
    }

    override fun getOutput(): ByteBuffer = output

    override fun isEnded(): Boolean = ended && !output.hasRemaining()

    override fun flush() {
        ended = false
        output = ByteBuffer.allocate(0)
    }

    override fun reset() {
        flush()
        active = false
    }
}

/**
 * Generates a short black clip (black video + silent audio) used as a
 * dip-to-black transition between scenes. Built with MediaCodec/MediaMuxer —
 * no FFmpeg involved.
 */
object BlackClipGenerator {
    fun generate(context: Context, width: Int, height: Int, durationMs: Int, outFile: File) {
        if (outFile.exists() && outFile.length() > 0) return
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // ---- video: solid black YUV420 frames ----
        val vFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
        vFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfoCompat.COLOR_FormatYUV420Flexible)
        vFormat.setInteger(MediaFormat.KEY_BIT_RATE, 400_000)
        vFormat.setInteger(MediaFormat.KEY_FRAME_RATE, 30)
        vFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val vEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        vEnc.configure(vFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        vEnc.start()
        val vTrack = muxer.addTrack(vEnc.outputFormat)
        val frameCount = (durationMs * 30 / 1000).coerceAtLeast(2)
        val ySize = width * height
        val blackFrame = ByteBuffer.allocateDirect(ySize * 3 / 2)
        repeat(ySize) { blackFrame.put(16.toByte()) } // Y = 16 (black)
        repeat(ySize / 2) { blackFrame.put(128.toByte()) } // U/V = 128
        blackFrame.flip()
        muxer.start()
        val vInfo = MediaCodec.BufferInfo()
        val frameUs = 1_000_000L / 30
        for (f in 0 until frameCount) {
            val inIdx = vEnc.dequeueInputBuffer(10_000)
            if (inIdx >= 0) {
                val inBuf = vEnc.getInputBuffer(inIdx)!!
                inBuf.clear()
                blackFrame.rewind()
                inBuf.put(blackFrame)
                val flags = if (f == frameCount - 1) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                vEnc.queueInputBuffer(inIdx, 0, ySize * 3 / 2, f * frameUs, flags)
            }
            drainEncoder(vEnc, muxer, vTrack, vInfo)
        }
        // flush remaining
        var flushing = true
        while (flushing) {
            val outIdx = vEnc.dequeueOutputBuffer(vInfo, 10_000)
            if (outIdx >= 0) {
                if (vInfo.size > 0) muxer.writeSampleData(vTrack, vEnc.getOutputBuffer(outIdx)!!, vInfo)
                vEnc.releaseOutputBuffer(outIdx, false)
                if (vInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) flushing = false
            } else if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) flushing = false
        }
        vEnc.stop(); vEnc.release()

        // ---- audio: silent AAC ----
        val aFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 2)
        aFormat.setInteger(MediaFormat.KEY_BIT_RATE, 64_000)
        aFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        val aEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        aEnc.configure(aFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        aEnc.start()
        val aTrack = muxer.addTrack(aEnc.outputFormat)
        val aInfo = MediaCodec.BufferInfo()
        val totalSamples = 44100 * durationMs / 1000
        var written = 0
        var audioEos = false
        while (!audioEos) {
            val inIdx = aEnc.dequeueInputBuffer(10_000)
            if (inIdx >= 0) {
                val inBuf = aEnc.getInputBuffer(inIdx)!!
                inBuf.clear()
                val chunk = minOf(2048, totalSamples - written)
                repeat(chunk * 2) { inBuf.putShort(0) } // silence, stereo 16-bit
                written += chunk
                val flags = if (written >= totalSamples) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                aEnc.queueInputBuffer(inIdx, 0, chunk * 4, written * 1_000_000L / 44100, flags)
                if (flags != 0) audioEos = true
            }
            drainEncoder(aEnc, muxer, aTrack, aInfo)
        }
        aEnc.stop(); aEnc.release()
        muxer.stop(); muxer.release()
    }

    private fun drainEncoder(
        enc: MediaCodec, muxer: MediaMuxer, track: Int, info: MediaCodec.BufferInfo
    ) {
        while (true) {
            val outIdx = enc.dequeueOutputBuffer(info, 0)
            if (outIdx >= 0) {
                if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                    muxer.writeSampleData(track, enc.getOutputBuffer(outIdx)!!, info)
                }
                enc.releaseOutputBuffer(outIdx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            } else return
        }
    }
}

/** Compatibility alias (avoids importing the full MediaCodecInfo in the generator). */
private object MediaCodecInfoCompat {
    const val COLOR_FormatYUV420Flexible =
        android.media.MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
}

/** One piece of the final timeline. */
private data class ExportItem(
    val startUs: Long,
    val endUs: Long,
    val caption: CaptionLine?,
    val index: Int
)

/**
 * Builds a Media3 [Composition] from the edit plan and exports it to MP4.
 *
 * What each requested feature maps to (honest mapping, no fake "AI"):
 * - Smart scene detection / auto cuts -> [EditPlan.keepSegments] (computed in [EditPlanner]).
 * - Dynamic zoom -> animated [MatrixTransformation] per segment (Ken Burns style).
 * - Color grading -> [Contrast]/[HslAdjustment]/[RgbFilter] presets.
 * - Transitions -> dip-to-black via generated black clips between segments.
 * - Captions/text overlays -> [TextOverlay] (segments are split at caption
 *   boundaries so each exported item shows exactly one static caption line).
 * - Audio normalize -> [GainAudioProcessor]; background music -> second audio
 *   sequence mixed by Transformer.
 * - Aspect ratios -> [Crop] + [Presentation]; export 720p/1080p MP4 (H.264/AAC).
 */
object VideoProcessor {

    class ExportFailedException(msg: String, cause: Throwable? = null) : Exception(msg, cause)

    suspend fun export(
        context: Context,
        inputUri: android.net.Uri,
        plan: EditPlan,
        options: RebrandOptions,
        meta: VideoMeta,
        outputFile: File,
        onProgress: (Float) -> Unit,
        isCancelled: () -> Boolean
    ): File = withContext(Dispatchers.IO) {
        val segments = plan.keepSegments
        if (segments.isEmpty()) {
            throw ExportFailedException(
                "Nothing left to export — every scene was removed. " +
                    "Keep at least one scene and try again."
            )
        }

        val targetH = options.quality.heightPx
        val (outW, outH) = outputSize(meta, options.aspectRatio, targetH)

        // 1) Split segments at caption boundaries so each item carries one caption.
        val items = buildExportItems(segments, plan.captions, options)

        // 2) Optional dip-to-black transition clips.
        val blackClip: File? = if (options.transitions && items.size > 1) {
            val f = File(context.cacheDir, "black_${outW}x${outH}.mp4")
            try {
                BlackClipGenerator.generate(context, outW, outH, 140, f)
                f
            } catch (e: Exception) {
                null // transitions degrade gracefully to hard cuts
            }
        } else null

        // 3) Build the main sequence.
        val editedItems = mutableListOf<EditedMediaItem>()
        items.forEachIndexed { i, item ->
            editedItems.add(buildEditedItem(context, inputUri, item, i, items.size, options, plan, meta, outW, outH, targetH))
            if (blackClip != null && i < items.lastIndex) {
                editedItems.add(
                    EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(blackClip))).build()
                )
            }
        }
        val sequences = mutableListOf(
            EditedMediaItemSequence.Builder().addItems(editedItems).build()
        )

        // 4) Optional background music as a second (audio) sequence.
        val totalUs = items.sumOf { it.endUs - it.startUs } +
            (if (blackClip != null) (items.size - 1) * 140_000L else 0L)
        options.backgroundMusicUri?.let { musicUri ->
            val musicItem = EditedMediaItem.Builder(
                MediaItem.Builder()
                    .setUri(musicUri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0)
                            .setEndPositionMs(totalUs / 1000)
                            .build()
                    )
                    .build()
            ).build()
            sequences.add(EditedMediaItemSequence.Builder().addItems(listOf(musicItem)).build())
        }

        val composition = Composition.Builder(sequences).build()

        val completion = CompletableDeferred<Unit>()
        val progressListener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, result: ExportResult) {
                completion.complete(Unit)
            }

            override fun onError(
                composition: Composition,
                result: ExportResult,
                exception: ExportException
            ) {
                completion.completeExceptionally(exception)
            }
        }
        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(progressListener)
            .build()

        if (outputFile.exists()) outputFile.delete()
        try {
            transformer.start(composition, outputFile.absolutePath)
        } catch (e: Exception) {
            throw ExportFailedException("Could not start export: ${e.message}", e)
        }

        // Poll progress until the listener completes the deferred; cancel cleanly.
        val progressHolder = ProgressHolder()
        try {
            while (!completion.isCompleted) {
                if (isCancelled()) {
                    transformer.cancel()
                    throw ExportFailedException("Export cancelled.")
                }
                if (transformer.getProgress(progressHolder) ==
                    Transformer.PROGRESS_STATE_AVAILABLE
                ) {
                    onProgress((progressHolder.progress / 100f).coerceIn(0f, 0.99f))
                }
                delay(250)
            }
            try {
                completion.await()
            } catch (e: ExportException) {
                throw ExportFailedException(friendlyError(e), e)
            }
        } finally {
            // Make sure a stuck transformer can never leak past this function.
            transformer.cancel()
        }
        onProgress(1f)
        return outputFile
    }

    // ------------------------------------------------------------------ items

    private fun buildExportItems(
        segments: List<KeepSegment>,
        captions: List<CaptionLine>,
        options: RebrandOptions
    ): List<ExportItem> {
        val items = mutableListOf<ExportItem>()
        var idx = 0
        for (seg in segments) {
            if (!options.aiCaptions || captions.isEmpty()) {
                items.add(ExportItem(seg.startUs, seg.endUs, null, idx++))
                continue
            }
            // Split at caption boundaries inside this segment.
            val bounds = sortedSetOf(seg.startUs, seg.endUs)
            for (c in captions) {
                if (c.endUs > seg.startUs && c.startUs < seg.endUs) {
                    bounds.add(c.startUs.coerceIn(seg.startUs, seg.endUs))
                    bounds.add(c.endUs.coerceIn(seg.startUs, seg.endUs))
                }
            }
            val pts = bounds.toList()
            for (i in 0 until pts.size - 1) {
                val s = pts[i]; val e = pts[i + 1]
                if (e - s < 80_000) continue // skip slivers
                val mid = (s + e) / 2
                val line = captions.firstOrNull { mid in it.startUs..it.endUs }
                items.add(ExportItem(s, e, line, idx++))
            }
        }
        return items
    }

    private fun buildEditedItem(
        context: Context,
        inputUri: android.net.Uri,
        item: ExportItem,
        index: Int,
        total: Int,
        options: RebrandOptions,
        plan: EditPlan,
        meta: VideoMeta,
        outW: Int,
        outH: Int,
        targetH: Int
    ): EditedMediaItem {
        val mediaItem = MediaItem.Builder()
            .setUri(inputUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(item.startUs / 1000)
                    .setEndPositionMs(item.endUs / 1000)
                    .build()
            )
            .build()

        val videoEffects = mutableListOf<Effect>()
        // Aspect ratio: center-crop to the target ratio, then scale to export height.
        cropForAspect(meta, options.aspectRatio)?.let { videoEffects.add(it) }
        videoEffects.add(Presentation.createForHeight(targetH))
        // Dynamic zoom: alternate push-in / pull-out per segment with easing.
        if (options.dynamicZoom) {
            val durationUs = (item.endUs - item.startUs).coerceAtLeast(1)
            val zoomIn = index % 2 == 0
            val maxZoom = if (options.style == com.qasapps.aivideorebrander.data.EditStyle.DYNAMIC) 1.22f else 1.12f
            videoEffects.add(MatrixTransformation { t ->
                val p = (t.coerceIn(0, durationUs) / durationUs.toFloat())
                    .let { it * it * (3 - 2 * it) } // smoothstep
                val scale = if (zoomIn) 1f + (maxZoom - 1f) * p else maxZoom - (maxZoom - 1f) * p
                Matrix().apply { postScale(scale, scale) }
            })
        }
        // Color grade presets.
        when (options.colorGrade) {
            ColorGrade.NONE -> {}
            ColorGrade.CINEMATIC_WARM -> {
                videoEffects.add(Contrast(1.07f))
                videoEffects.add(
                    HslAdjustment.Builder().adjustSaturation(12f).adjustLightness(-4f).build()
                )
            }
            ColorGrade.VIVID -> {
                videoEffects.add(Contrast(1.16f))
                videoEffects.add(
                    HslAdjustment.Builder().adjustSaturation(28f).build()
                )
            }
            ColorGrade.NOIR -> videoEffects.add(RgbFilter.createGrayscaleFilter())
        }
        // Overlays: title card on first item, brand watermark everywhere, captions per item.
        val overlays = mutableListOf<TextureOverlay>()
        if (index == 0 && options.titleOverlay.isNotBlank()) {
            overlays.add(
                TextOverlay.createStaticTextOverlay(
                    styled(options.titleOverlay.trim()),
                    StaticOverlaySettings.Builder()
                        .setOverlayFrameAnchor(0f, 1f)
                        .setBackgroundFrameAnchor(0f, 0.88f)
                        .build()
                )
            )
        }
        if (options.brandOverlay.isNotBlank()) {
            overlays.add(
                TextOverlay.createStaticTextOverlay(
                    styled(options.brandOverlay.trim()),
                    StaticOverlaySettings.Builder()
                        .setOverlayFrameAnchor(-1f, -1f)
                        .setBackgroundFrameAnchor(-0.94f, -0.94f)
                        .build()
                )
            )
        }
        item.caption?.let { line ->
            if (line.text.isNotBlank()) {
                overlays.add(
                    TextOverlay.createStaticTextOverlay(
                        styled(line.text),
                        StaticOverlaySettings.Builder()
                            .setOverlayFrameAnchor(0f, -1f)
                            .setBackgroundFrameAnchor(0f, -0.9f)
                            .build()
                    )
                )
            }
        }
        if (overlays.isNotEmpty()) videoEffects.add(OverlayEffect(overlays))

        val audioProcessors = mutableListOf<AudioProcessor>()
        if (options.normalizeAudio && plan.audioPeak > 1e-4f) {
            val gain = (0.89f / plan.audioPeak).coerceIn(1f, 8f)
            if (gain > 1.02f) audioProcessors.add(GainAudioProcessor(gain))
        }

        return EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(audioProcessors, videoEffects))
            .build()
    }

    private fun styled(text: String): SpannableString =
        SpannableString(text).apply {
            setSpan(
                ForegroundColorSpan(Color.WHITE), 0, length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

    /** Center-crop effect to reach the requested aspect ratio, or null if none needed. */
    private fun cropForAspect(meta: VideoMeta, aspect: AspectRatioOption): Crop? {
        if (aspect == AspectRatioOption.ORIGINAL || meta.width <= 0 || meta.height <= 0) return null
        val target = aspect.w.toFloat() / aspect.h
        val input = meta.width.toFloat() / meta.height
        if (kotlin.math.abs(input - target) < 0.01f) return null
        return if (input > target) {
            // Input wider: crop the sides, keep full height.
            val keep = (target / input).coerceIn(0.05f, 1f)
            Crop(-keep, keep, -1f, 1f)
        } else {
            // Input taller: crop top/bottom, keep full width.
            val keep = (input / target).coerceIn(0.05f, 1f)
            Crop(-1f, 1f, -keep, keep)
        }
    }

    private fun outputSize(meta: VideoMeta, aspect: AspectRatioOption, targetH: Int): Pair<Int, Int> {
        val ratio = when (aspect) {
            AspectRatioOption.ORIGINAL ->
                if (meta.width > 0 && meta.height > 0) meta.width.toFloat() / meta.height else 16f / 9f
            else -> aspect.w.toFloat() / aspect.h
        }
        val w = (targetH * ratio / 2).roundToInt() * 2
        return w to targetH
    }

    private fun friendlyError(e: ExportException): String {
        val c = e.errorCode
        return when (c) {
            ExportException.ERROR_CODE_DECODING_FAILED ->
                "Could not decode this video. It may use an unsupported codec — try another file."
            ExportException.ERROR_CODE_ENCODING_FAILED ->
                "Encoding failed on this device (possibly low memory). Close other apps and try 720p."
            ExportException.ERROR_CODE_MUXING_FAILED ->
                "Could not write the MP4 file. Check free storage space and try again."
            ExportException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                "A media file could not be found. Re-select your video or music and try again."
            else -> "Export failed (code $c): ${e.message}"
        }
    }
}
