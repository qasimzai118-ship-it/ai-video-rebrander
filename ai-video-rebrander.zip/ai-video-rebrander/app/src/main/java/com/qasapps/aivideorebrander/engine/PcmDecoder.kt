package com.qasapps.aivideorebrander.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * Decodes the audio track of [uri] to mono 16-bit PCM.
 *
 * Returns the raw samples at the track's native sample rate together with the
 * peak amplitude (0..1) seen while decoding. The peak is used for loudness
 * normalization; callers that need 16 kHz (Vosk) can use [resampleMono16k].
 *
 * Throws [IllegalArgumentException] when the file has no audio track.
 */
object PcmDecoder {

    data class PcmAudio(
        val samples: ShortArray, // mono, native sample rate
        val sampleRate: Int,
        val peak: Float // 0..1
    )

    fun decodeMono(context: Context, uri: Uri): PcmAudio {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            require(trackIndex >= 0) { "No audio track found in this video." }
            val inputFormat = format!!
            extractor.selectTrack(trackIndex)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            val channelCount = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 2

            val out = mutableListOf<Short>()
            var peak = 0f
            val bufferInfo = MediaCodec.BufferInfo()
            var sawInputEos = false
            var sawOutputEos = false

            while (!sawOutputEos) {
                if (!sawInputEos) {
                    val inIndex = codec.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val inBuf = codec.getInputBuffer(inIndex)!!
                        val read = extractor.readSampleData(inBuf, 0)
                        if (read < 0) {
                            codec.queueInputBuffer(
                                inIndex, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            sawInputEos = true
                        } else {
                            codec.queueInputBuffer(
                                inIndex, 0, read,
                                extractor.sampleTime, extractor.sampleFlags
                            )
                            extractor.advance()
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIndex >= 0 -> {
                        val outBuf = codec.getOutputBuffer(outIndex)!!
                        drainToMono(outBuf, bufferInfo, channelCount, out) { p ->
                            if (p > peak) peak = p
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            sawOutputEos = true
                        }
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { /* ignore */ }
                }
            }
            codec.stop()
            codec.release()
            return PcmAudio(out.toShortArray(), sampleRate, peak.coerceAtLeast(1e-4f))
        } finally {
            extractor.release()
        }
    }

    private fun drainToMono(
        buf: ByteBuffer,
        info: MediaCodec.BufferInfo,
        channelCount: Int,
        out: MutableList<Short>,
        onPeak: (Float) -> Unit
    ) {
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        buf.order(ByteOrder.LITTLE_ENDIAN)
        val frames = info.size / 2 / channelCount.coerceAtLeast(1)
        repeat(frames) {
            var sum = 0
            repeat(channelCount.coerceAtLeast(1)) {
                if (buf.remaining() >= 2) sum += buf.short.toInt()
            }
            val mono = (sum / channelCount.coerceAtLeast(1)).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            out.add(mono)
            val amp = kotlin.math.abs(mono.toInt()) / 32768f
            onPeak(amp)
        }
    }

    /** Naive linear resample of mono 16-bit PCM to 16 kHz (what Vosk expects). */
    fun resampleMono16k(samples: ShortArray, fromRate: Int): ShortArray {
        if (fromRate == 16000) return samples
        val ratio = 16000.0 / fromRate
        val outLen = (samples.size * ratio).roundToInt().coerceAtLeast(1)
        val out = ShortArray(outLen)
        for (i in out.indices) {
            val srcPos = i / ratio
            val i0 = srcPos.toInt().coerceIn(0, samples.size - 1)
            val i1 = (i0 + 1).coerceIn(0, samples.size - 1)
            val frac = (srcPos - i0).toFloat()
            val v = samples[i0] * (1 - frac) + samples[i1] * frac
            out[i] = v.roundToInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return out
    }
}
