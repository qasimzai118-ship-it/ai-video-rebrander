package com.qasapps.aivideorebrander.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.qasapps.aivideorebrander.data.EditPlan
import com.qasapps.aivideorebrander.data.RebrandOptions
import com.qasapps.aivideorebrander.data.VideoMeta
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** UI-visible state of the re-edit pipeline. */
sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val stage: String, val progress: Float) : ExportState
    data class Done(val outputFile: File) : ExportState
    data class Error(val message: String) : ExportState
    data object Cancelled : ExportState
}

/** Everything the preview screen needs to offer "adjust & re-export". */
data class ExportSession(
    val inputUri: Uri,
    val options: RebrandOptions,
    val meta: VideoMeta,
    val outputFile: File
)

/** Process-wide hub shared by the service and the UI (same process). */
object ExportHub {
    private val _state = MutableStateFlow<ExportState>(ExportState.Idle)
    val state: StateFlow<ExportState> = _state.asStateFlow()

    @Volatile var session: ExportSession? = null
    @Volatile var plan: EditPlan? = null
    /** Non-fatal note from the last run (e.g. why captions were skipped). */
    @Volatile var lastNote: String? = null
    val cancelled = AtomicBoolean(false)

    fun update(state: ExportState) { _state.value = state }
}

/**
 * Foreground service that runs the whole "Auto Re-Edit" pipeline:
 * analysis (scenes, silence, captions) + Transformer export.
 *
 * Running it here (instead of the Activity) keeps long exports alive when the
 * screen rotates or the app goes to the background, shows a progress
 * notification, and supports cancellation. The user can cancel at any time;
 * partial output files are deleted.
 */
class ExportService : Service() {

    companion object {
        const val ACTION_START = "com.qasapps.aivideorebrander.START"
        const val ACTION_REEXPORT = "com.qasapps.aivideorebrander.REEXPORT"
        const val ACTION_CANCEL = "com.qasapps.aivideorebrander.CANCEL"
        const val EXTRA_INPUT_URI = "input_uri"
        const val EXTRA_OPTIONS = "options"
        const val EXTRA_META = "meta"
        const val EXTRA_MODEL_CONSENT = "model_consent"

        private const val CHANNEL_ID = "rebrand_export"
        private const val NOTIF_ID = 42

        fun start(context: Context, inputUri: Uri, options: RebrandOptions, meta: VideoMeta, modelConsent: Boolean) {
            val i = Intent(context, ExportService::class.java).setAction(ACTION_START)
                .putExtra(EXTRA_INPUT_URI, inputUri)
                .putExtra(EXTRA_OPTIONS, options)
                .putExtra(EXTRA_META, meta)
                .putExtra(EXTRA_MODEL_CONSENT, modelConsent)
            context.startForegroundService(i)
        }

        fun reexport(context: Context) {
            context.startForegroundService(
                Intent(context, ExportService::class.java).setAction(ACTION_REEXPORT)
            )
        }

        fun cancel(context: Context) {
            context.startService(
                Intent(context, ExportService::class.java).setAction(ACTION_CANCEL)
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var notifManager: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        notifManager = getSystemService(NotificationManager::class.java)
        notifManager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Video export", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                ExportHub.cancelled.set(true)
                job?.cancel()
                cleanupAfterStop(cancelledByUser = true)
            }
            ACTION_START -> {
                if (job?.isActive == true) return START_NOT_STICKY
                val uri: Uri? = intent.getParcelableExtra(EXTRA_INPUT_URI)
                val options: RebrandOptions? = intent.getParcelableExtra(EXTRA_OPTIONS)
                val meta: VideoMeta? = intent.getParcelableExtra(EXTRA_META)
                val consent = intent.getBooleanExtra(EXTRA_MODEL_CONSENT, false)
                if (uri == null || options == null || meta == null) {
                    ExportHub.update(ExportState.Error("Missing input. Please pick your video again."))
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(NOTIF_ID, buildNotification("Preparing…", 0))
                ExportHub.cancelled.set(false)
                job = scope.launch { runFullPipeline(uri, options, meta, consent) }
            }
            ACTION_REEXPORT -> {
                if (job?.isActive == true) return START_NOT_STICKY
                val session = ExportHub.session
                val plan = ExportHub.plan
                if (session == null || plan == null) {
                    ExportHub.update(ExportState.Error("Nothing to re-export yet."))
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(NOTIF_ID, buildNotification("Re-exporting…", 0))
                ExportHub.cancelled.set(false)
                job = scope.launch { runExportOnly(session, plan) }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun runFullPipeline(
        uri: Uri, options: RebrandOptions, meta: VideoMeta, modelConsent: Boolean
    ) {
        val outputFile = File(cacheDir, "rebrand_preview.mp4")
        try {
            setStage("Reading video…", 0.02f)

            // 1) Scene detection (honest heuristic — see SceneDetector docs).
            val scenes = if (options.detectScenes) {
                SceneDetector.detect(this, uri, meta.durationUs) { p ->
                    setStage("Detecting scenes…", 0.02f + p * 0.13f)
                }
            } else emptyList()
            checkCancelled()

            // 2) Decode audio once; reuse for silence, normalization and captions.
            setStage("Analyzing audio…", 0.16f)
            val pcm = try {
                PcmDecoder.decodeMono(this, uri)
            } catch (e: IllegalArgumentException) {
                // Video without an audio track: proceed video-only.
                null
            }
            checkCancelled()

            val silences = if (options.cutSilence && pcm != null) {
                SilenceDetector.detect(pcm.samples, pcm.sampleRate) { p ->
                    setStage("Finding silent parts…", 0.16f + p * 0.10f)
                }
            } else emptyList()
            checkCancelled()

            // 3) On-device captions (Vosk). Never faked: missing model + no
            //    consent => captions are skipped with a clear note.
            var captions = emptyList<com.qasapps.aivideorebrander.data.CaptionLine>()
            var captionNote: String? = null
            if (options.aiCaptions) {
                if (pcm == null) {
                    captionNote = "Skipped captions: this video has no audio track."
                } else if (!CaptionEngine.isModelInstalled(this) && !modelConsent) {
                    captionNote = "Skipped captions: speech model not downloaded."
                } else {
                    setStage("Loading speech model…", 0.27f)
                    try {
                        val modelDir = CaptionEngine.ensureModel(this) { p ->
                            setStage("Downloading speech model…", 0.27f + p * 0.08f)
                        }
                        checkCancelled()
                        val pcm16k = PcmDecoder.resampleMono16k(pcm.samples, pcm.sampleRate)
                        captions = CaptionEngine.transcribe(
                            pcm16k, modelDir, options.captionAllCaps
                        ) { p -> setStage("Transcribing speech…", 0.35f + p * 0.15f) }
                        if (captions.isEmpty()) {
                            captionNote = "No speech was recognized — captions left empty."
                        }
                    } catch (e: Exception) {
                        captionNote = "Captions failed: ${e.message}"
                    }
                }
            }
            checkCancelled()

            // 4) Build the editable plan.
            setStage("Planning edits…", 0.52f)
            var plan = EditPlanner.build(options, scenes, silences, meta.durationUs, pcm?.peak ?: 0f)
            plan = plan.copy(captions = captions)
            ExportHub.plan = plan
            checkCancelled()

            // 5) Export.
            val session = ExportSession(uri, options, meta, outputFile)
            ExportHub.session = session
            VideoProcessor.export(
                this, uri, plan, options, meta, outputFile,
                onProgress = { p -> setStage("Exporting video…", 0.55f + p * 0.45f) },
                isCancelled = { ExportHub.cancelled.get() }
            )
            ExportHub.update(ExportState.Done(outputFile))
            notifManager.notify(NOTIF_ID, buildNotification("Export finished", 1f, done = true))
            ExportHub.lastNote = captionNote
        } catch (e: VideoProcessor.ExportFailedException) {
            if (e.message == "Export cancelled." || ExportHub.cancelled.get()) {
                cleanupAfterStop(cancelledByUser = true)
            } else fail(e.message ?: "Export failed.")
        } catch (e: Exception) {
            if (ExportHub.cancelled.get()) cleanupAfterStop(cancelledByUser = true)
            else fail(e.message ?: "Something went wrong.")
        } finally {
            stopSelf()
        }
    }

    private suspend fun runExportOnly(session: ExportSession, plan: EditPlan) {
        try {
            VideoProcessor.export(
                this, session.inputUri, plan, session.options, session.meta,
                session.outputFile,
                onProgress = { p -> setStage("Exporting video…", p) },
                isCancelled = { ExportHub.cancelled.get() }
            )
            ExportHub.update(ExportState.Done(session.outputFile))
            notifManager.notify(NOTIF_ID, buildNotification("Export finished", 1f, done = true))
        } catch (e: VideoProcessor.ExportFailedException) {
            if (ExportHub.cancelled.get()) cleanupAfterStop(cancelledByUser = true)
            else fail(e.message ?: "Export failed.")
        } catch (e: Exception) {
            if (ExportHub.cancelled.get()) cleanupAfterStop(cancelledByUser = true)
            else fail(e.message ?: "Something went wrong.")
        } finally {
            stopSelf()
        }
    }

    private fun checkCancelled() {
        if (ExportHub.cancelled.get()) throw VideoProcessor.ExportFailedException("Export cancelled.")
    }

    private fun setStage(stage: String, progress: Float) {
        ExportHub.update(ExportState.Running(stage, progress.coerceIn(0f, 1f)))
        notifManager.notify(NOTIF_ID, buildNotification(stage, progress.coerceIn(0f, 1f)))
    }

    private fun fail(message: String) {
        ExportHub.session?.outputFile?.delete()
        ExportHub.update(ExportState.Error(message))
        notifManager.notify(NOTIF_ID, buildNotification("Export failed", 0f, done = true))
    }

    private fun cleanupAfterStop(cancelledByUser: Boolean) {
        ExportHub.session?.outputFile?.delete()
        if (cancelledByUser) ExportHub.update(ExportState.Cancelled)
        notifManager.cancel(NOTIF_ID)
        stopSelf()
    }

    private fun buildNotification(stage: String, progress: Float, done: Boolean = false): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AI Video Rebrander")
            .setContentText(stage)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(!done)
            .setOnlyAlertOnce(true)
            .setProgress(100, (progress * 100).toInt(), false)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
