package com.qasapps.aivideorebrander.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF7C4DFF),
    secondary = Color(0xFF00E5A0),
    background = Color(0xFF0E0E12),
    surface = Color(0xFF17171D),
    onPrimary = Color.White,
    onBackground = Color(0xFFF2F2F5),
    onSurface = Color(0xFFF2F2F5)
)

@Composable
fun RebranderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
