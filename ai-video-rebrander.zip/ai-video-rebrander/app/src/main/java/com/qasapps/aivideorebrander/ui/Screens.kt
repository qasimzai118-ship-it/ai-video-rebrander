package com.qasapps.aivideorebrander.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.qasapps.aivideorebrander.RebrandViewModel
import com.qasapps.aivideorebrander.data.AspectRatioOption
import com.qasapps.aivideorebrander.data.ColorGrade
import com.qasapps.aivideorebrander.data.EditStyle
import com.qasapps.aivideorebrander.data.ExportQuality
import com.qasapps.aivideorebrander.engine.CaptionEngine
import com.qasapps.aivideorebrander.engine.ExportService

// ---------------------------------------------------------------- home

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: RebrandViewModel, nav: NavController) {
    val context = LocalContext.current

    // Only extra permission the app needs: show export progress notifications.
    // Video/music access comes from the system file picker itself.
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val pickVideo = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) vm.pickVideo(context, uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("AI Video Rebrander", fontWeight = FontWeight.Bold) }) }
    ) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Pick a video and get a freshly re-edited cut: smart cuts, " +
                    "zooms, grades, captions and more.",
                style = MaterialTheme.typography.bodyLarge
            )
            Button(onClick = { pickVideo.launch(arrayOf("video/*")) }) {
                Icon(Icons.Default.VideoLibrary, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (vm.inputUri == null) "Select video" else "Select a different video")
            }
            vm.loadError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            vm.thumbnail?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Selected video",
                    modifier = Modifier.size(220.dp).clip(RoundedCornerShape(16.dp))
                )
            }
            vm.meta?.let { meta ->
                val secs = meta.durationUs / 1_000_000
                Text(
                    "${meta.width}×${meta.height} • ${secs / 60}:${"%02d".format(secs % 60)}" +
                        if (!meta.hasAudio) " • no audio" else "",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { nav.navigate("style") }) {
                    Text("Continue")
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- style

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StyleScreen(vm: RebrandViewModel, nav: NavController) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Choose an editing style") }) }
    ) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            EditStyle.entries.forEach { style ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        vm.chooseStyle(style)
                        nav.navigate("options")
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (vm.options.style == style)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(style.title, fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium)
                            Text(style.blurb, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (vm.options.style == style) {
                            Icon(Icons.Default.Check, contentDescription = "Selected",
                                tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- options

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionsScreen(vm: RebrandViewModel, nav: NavController) {
    val context = LocalContext.current
    val o = vm.options
    var showModelDialog by remember { mutableStateOf(false) }

    val pickMusic = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            vm.options = o.copy(backgroundMusicUri = uri)
        }
    }

    fun startExport(modelConsent: Boolean) {
        val meta = vm.meta ?: return
        val uri = vm.inputUri ?: return
        ExportService.start(context, uri, vm.options, meta, modelConsent)
        nav.navigate("processing") { popUpTo("options") { inclusive = false } }
    }

    if (showModelDialog) {
        AlertDialog(
            onDismissRequest = { showModelDialog = false },
            title = { Text("On-device speech model") },
            text = {
                Text(
                    "Captions run 100% on your phone with the free Vosk speech model " +
                        "(~40 MB, downloaded once from alphacephei.com). No audio ever " +
                        "leaves your device and nothing is paid."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showModelDialog = false
                    startExport(modelConsent = true)
                }) { Text("Download & continue") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showModelDialog = false
                    vm.options = o.copy(aiCaptions = false)
                    startExport(modelConsent = false)
                }) { Text("Skip captions") }
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Editing options") }) }
    ) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SectionTitle("Automatic edits")
            ToggleRow("Smart scene detection",
                "Finds cuts with frame analysis; scenes become editable clips.",
                o.detectScenes) { vm.options = o.copy(detectScenes = it) }
            ToggleRow("Cut silent parts",
                "Removes pauses and dead air, keeps the good stuff.",
                o.cutSilence) { vm.options = o.copy(cutSilence = it) }
            ToggleRow("Dynamic zoom",
                "Scene-aware push-in / pull-out motion on every clip.",
                o.dynamicZoom) { vm.options = o.copy(dynamicZoom = it) }
            ToggleRow("Dip-to-black transitions",
                "Short fade through black between scenes.",
                o.transitions) { vm.options = o.copy(transitions = it) }
            ToggleRow("AI captions (on-device)",
                "Speech-to-text with editable words and styling. Free, offline.",
                o.aiCaptions) { vm.options = o.copy(aiCaptions = it) }
            if (o.aiCaptions) {
                ToggleRow("Captions in ALL CAPS", "Bold social-media caption look.",
                    o.captionAllCaps) { vm.options = o.copy(captionAllCaps = it) }
            }
            ToggleRow("Normalize audio",
                "Evens out volume so quiet clips aren't lost.",
                o.normalizeAudio) { vm.options = o.copy(normalizeAudio = it) }

            SectionTitle("Look")
            ChipRow(
                title = "Color grade",
                items = ColorGrade.entries.map { it.title },
                selected = o.colorGrade.ordinal,
                onSelect = { vm.options = o.copy(colorGrade = ColorGrade.entries[it]) }
            )
            ChipRow(
                title = "Aspect ratio",
                items = AspectRatioOption.entries.map { it.title },
                selected = o.aspectRatio.ordinal,
                onSelect = { vm.options = o.copy(aspectRatio = AspectRatioOption.entries[it]) }
            )
            ChipRow(
                title = "Export quality",
                items = ExportQuality.entries.map { it.title },
                selected = o.quality.ordinal,
                onSelect = { vm.options = o.copy(quality = ExportQuality.entries[it]) }
            )

            SectionTitle("Text & branding")
            OutlinedTextField(
                value = o.titleOverlay,
                onValueChange = { vm.options = o.copy(titleOverlay = it) },
                label = { Text("Title card (shows at the start)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = o.brandOverlay,
                onValueChange = { vm.options = o.copy(brandOverlay = it) },
                label = { Text("Watermark / handle, e.g. @qasfood") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )

            SectionTitle("Music")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickMusic.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (o.backgroundMusicUri == null) "Pick music" else "Change music")
                }
                if (o.backgroundMusicUri != null) {
                    TextButton(onClick = { vm.options = o.copy(backgroundMusicUri = null) }) {
                        Icon(Icons.Default.Clear, contentDescription = "Remove music")
                    }
                }
            }
            if (o.backgroundMusicUri != null) {
                Text("Music volume: ${(o.musicVolume * 100).toInt()}%")
                Slider(
                    value = o.musicVolume,
                    onValueChange = { vm.options = o.copy(musicVolume = it) },
                    valueRange = 0.05f..1f
                )
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (o.aiCaptions && !CaptionEngine.isModelInstalled(context)) {
                        showModelDialog = true
                    } else {
                        startExport(modelConsent = true)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("Auto Re-Edit", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text, fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.titleSmall,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun ToggleRow(
    title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChipRow(
    title: String, items: List<String>, selected: Int, onSelect: (Int) -> Unit
) {
    Text(title, style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEachIndexed { i, label ->
            FilterChip(
                selected = selected == i,
                onClick = { onSelect(i) },
                label = { Text(label) }
            )
        }
    }
}
