package com.qasapps.aivideorebrander.engine

import android.content.Context
import com.qasapps.aivideorebrander.data.CaptionLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * On-device speech-to-text using Vosk (Apache 2.0). No audio ever leaves the
 * phone and no paid/cloud API is used.
 *
 * The small English model (~40 MB) is downloaded once from the official Vosk
 * site on first use (with the user's consent via the UI), then reused offline.
 * If the model is missing and the user declines the download, caption
 * generation is skipped with a clear message — nothing is faked.
 */
object CaptionEngine {

    // Canonical small English model. Verify on https://alphacephei.com/vosk/models
    // if this ever 404s; any 16 kHz Vosk model unzipped into filesDir works.
    private const val MODEL_URL =
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val MODEL_DIR_NAME = "vosk-model-small-en-us-0.15"

    class ModelMissingException(msg: String) : Exception(msg)

    /**
     * Returns the model directory, downloading + unzipping it first if needed.
     * Must be called off the main thread.
     */
    suspend fun ensureModel(context: Context, onProgress: (Float) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.filesDir, MODEL_DIR_NAME)
            if (isValidModelDir(dir)) return@withContext dir
            val zip = File(context.cacheDir, "vosk-model.zip")
            try {
                download(MODEL_URL, zip, onProgress)
                unzip(zip, context.filesDir, onProgress)
            } finally {
                zip.delete()
            }
            if (!isValidModelDir(dir)) {
                throw ModelMissingException(
                    "The speech model could not be installed. Check your connection and try again."
                )
            }
            dir
        }

    fun isModelInstalled(context: Context): Boolean =
        isValidModelDir(File(context.filesDir, MODEL_DIR_NAME))

    private fun isValidModelDir(dir: File): Boolean =
        dir.isDirectory && File(dir, "am/final.mdl").exists()

    private fun download(url: String, dest: File, onProgress: (Float) -> Unit) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
        }
        conn.connect()
        val total = conn.contentLengthLong.coerceAtLeast(1)
        BufferedInputStream(conn.inputStream).use { input ->
            FileOutputStream(dest).use { output ->
                val buf = ByteArray(64 * 1024)
                var read: Int
                var done = 0L
                while (input.read(buf).also { read = it } != -1) {
                    output.write(buf, 0, read)
                    done += read
                    onProgress((done / total.toFloat()).coerceIn(0f, 1f) * 0.7f)
                }
            }
        }
    }

    private fun unzip(zip: File, destDir: File, onProgress: (Float) -> Unit) {
        ZipInputStream(BufferedInputStream(zip.inputStream())).use { zin ->
            val buf = ByteArray(64 * 1024)
            var entries = 0
            var entry = zin.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                if (!outFile.canonicalPath.startsWith(destDir.canonicalPath)) {
                    throw SecurityException("Zip entry escapes target dir: ${entry.name}")
                }
                if (entry.isDirectory) outFile.mkdirs()
                else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        var read: Int
                        while (zin.read(buf).also { read = it } != -1) out.write(buf, 0, read)
                    }
                }
                entries++
                if (entries % 200 == 0) onProgress(0.7f + (entries % 1000) / 1000f * 0.3f)
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
        onProgress(1f)
    }

    data class Word(val text: String, val startUs: Long, val endUs: Long)

    /**
     * Transcribes 16 kHz mono PCM. Returns caption lines with word-level timing
     * grouped into readable chunks. Runs fully on-device.
     */
    suspend fun transcribe(
        pcm16k: ShortArray,
        modelDir: File,
        allCaps: Boolean,
        onProgress: (Float) -> Unit
    ): List<CaptionLine> = withContext(Dispatchers.Default) {
        val model = Model(modelDir.absolutePath)
        try {
            val recognizer = Recognizer(model, 16000f)
            try {
                recognizer.setWords(true)
                val words = mutableListOf<Word>()
                val chunk = 16000 * 2 // 2-second chunks
                var offset = 0
                while (offset < pcm16k.size) {
                    val len = minOf(chunk, pcm16k.size - offset)
                    val data = pcm16k.copyOfRange(offset, offset + len)
                    if (recognizer.acceptWaveForm(data, len)) {
                        words += parseWords(recognizer.result)
                    } else {
                        words += parseWords(recognizer.partialResult, partial = true)
                    }
                    offset += len
                    onProgress(offset / pcm16k.size.toFloat())
                }
                words += parseWords(recognizer.finalResult)
                groupIntoLines(words, allCaps)
            } finally {
                recognizer.close()
            }
        } finally {
            model.close()
        }
    }

    private fun parseWords(json: String, partial: Boolean = false): List<Word> {
        val out = mutableListOf<Word>()
        try {
            val root = JSONObject(json)
            if (partial) {
                // Partial results have no timings; skip them (final pass covers all).
                return out
            }
            val arr = root.optJSONArray("result") ?: return out
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                val text = w.optString("word", "").trim()
                if (text.isEmpty()) continue
                out.add(
                    Word(
                        text,
                        (w.optDouble("start", 0.0) * 1_000_000).toLong(),
                        (w.optDouble("end", 0.0) * 1_000_000).toLong()
                    )
                )
            }
        } catch (_: Exception) { /* malformed chunk -> skip */ }
        return out
    }

    private fun groupIntoLines(words: List<Word>, allCaps: Boolean): List<CaptionLine> {
        val lines = mutableListOf<CaptionLine>()
        val current = mutableListOf<Word>()
        fun flush() {
            if (current.isEmpty()) return
            var text = current.joinToString(" ") { it.text }
            if (allCaps) text = text.uppercase()
            lines.add(CaptionLine(current.first().startUs, current.last().endUs, text))
            current.clear()
        }
        for (w in words) {
            val gapOk = current.isEmpty() ||
                w.startUs - current.last().endUs < 800_000
            val sizeOk = current.size < 9 &&
                (current.isEmpty() || w.endUs - current.first().startUs < 5_000_000)
            if (!gapOk || !sizeOk) flush()
            current.add(w)
        }
        flush()
        return lines.filter { it.text.isNotBlank() && it.endUs > it.startUs }
    }
}
