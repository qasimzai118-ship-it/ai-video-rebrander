package com.qasapps.aivideorebrander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.qasapps.aivideorebrander.ui.HomeScreen
import com.qasapps.aivideorebrander.ui.OptionsScreen
import com.qasapps.aivideorebrander.ui.PreviewScreen
import com.qasapps.aivideorebrander.ui.ProcessingScreen
import com.qasapps.aivideorebrander.ui.RebranderTheme
import com.qasapps.aivideorebrander.ui.StyleScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RebranderTheme {
                val vm: RebrandViewModel = viewModel()
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") { HomeScreen(vm, nav) }
                    composable("style") { StyleScreen(vm, nav) }
                    composable("options") { OptionsScreen(vm, nav) }
                    composable("processing") { ProcessingScreen(vm, nav) }
                    composable("preview") { PreviewScreen(vm, nav) }
                }
            }
        }
    }
}
