package com.qasapps.aivideorebrander.engine

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.qasapps.aivideorebrander.data.Scene
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Detects scene cuts with a classic, explainable computer-vision heuristic
 * (NOT a neural network — the UI labels it honestly as "scene detection"):
 *
 * 1. Sample one small frame every [sampleStepMs].
 * 2. Build a coarse 4x4x4 RGB histogram per frame.
 * 3. Measure chi-square distance between consecutive histograms.
 * 4. A cut is declared when the distance exceeds an adaptive threshold
 *    (mean + k * stddev of all distances), with a minimum scene length guard.
 */
object SceneDetector {

    private const val SAMPLE_W = 48
    private const val SAMPLE_H = 27
    private const val BINS_PER_CHANNEL = 4 // 4^3 = 64 bins
    private const val STD_K = 2.5
    private const val MIN_SCENE_MS = 700L

    fun detect(
        context: Context,
        uri: Uri,
        durationUs: Long,
        sampleStepMs: Long = 400L,
        onProgress: (Float) -> Unit = {}
    ): List<Scene> {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = durationUs / 1000
            if (durationMs <= 0) return listOf(Scene(0, 0, durationUs))

            val timesMs = generateSequence(0L) { it + sampleStepMs }
                .takeWhile { it < durationMs }
                .toList()
            if (timesMs.size < 2) return listOf(Scene(0, 0, durationUs))

            val histograms = ArrayList<FloatArray>(timesMs.size)
            timesMs.forEachIndexed { idx, t ->
                val frame = retriever.getFrameAtTime(
                    t * 1000,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                )
                histograms.add(histogram(frame))
                frame?.recycle()
                onProgress(idx / timesMs.size.toFloat() * 0.9f)
            }

            val distances = FloatArray(histograms.size - 1) { i ->
                chiSquare(histograms[i], histograms[i + 1])
            }
            val mean = distances.average().toFloat()
            val std = sqrt(distances.map { (it - mean) * (it - mean) }.average()).toFloat()
            // Adaptive threshold, with a floor so near-static videos don't over-cut.
            val threshold = maxOf(mean + STD_K * std, mean * 1.6f + 1e-3f)

            val cuts = mutableListOf<Long>()
            var lastCutMs = 0L
            distances.forEachIndexed { i, d ->
                val t = timesMs[i + 1]
                if (d > threshold && t - lastCutMs >= MIN_SCENE_MS) {
                    cuts.add(t)
                    lastCutMs = t
                }
            }
            onProgress(1f)

            val bounds = listOf(0L) + cuts + listOf(durationMs)
            return bounds.zipWithNext().mapIndexed { index, (s, e) ->
                Scene(index, s * 1000, e * 1000)
            }
        } finally {
            retriever.release()
        }
    }

    private fun histogram(frame: Bitmap?): FloatArray {
        val bins = FloatArray(BINS_PER_CHANNEL * BINS_PER_CHANNEL * BINS_PER_CHANNEL)
        if (frame == null) return bins
        val small = Bitmap.createScaledBitmap(frame, SAMPLE_W, SAMPLE_H, true)
        val pixels = IntArray(SAMPLE_W * SAMPLE_H)
        small.getPixels(pixels, 0, SAMPLE_W, 0, 0, SAMPLE_W, SAMPLE_H)
        val shift = 8 - 2 // 4 bins per channel -> top 2 bits
        for (p in pixels) {
            val r = (p shr 16 and 0xFF) shr shift
            val g = (p shr 8 and 0xFF) shr shift
            val b = (p and 0xFF) shr shift
            bins[(r * BINS_PER_CHANNEL + g) * BINS_PER_CHANNEL + b]++
        }
        small.recycle()
        val n = pixels.size.toFloat()
        for (i in bins.indices) bins[i] /= n
        return bins
    }

    private fun chiSquare(a: FloatArray, b: FloatArray): Float {
        var sum = 0.0
        for (i in a.indices) {
            val denom = a[i] + b[i] + 1e-6
            val diff = a[i] - b[i]
            sum += diff * diff / denom
        }
        return (0.5 * sum).toFloat()
    }
}

/**
 * Finds silent stretches in decoded PCM audio using short-window RMS energy
 * with an adaptive threshold (a multiple of the 15th percentile window energy).
 * Returns silence intervals as (startUs, endUs) pairs.
 */
object SilenceDetector {

    private const val WINDOW_MS = 100L

    fun detect(
        samples: ShortArray,
        sampleRate: Int,
        minSilenceMs: Long = 600L,
        onProgress: (Float) -> Unit = {}
    ): List<Pair<Long, Long>> {
        if (samples.isEmpty()) return emptyList()
        val windowSize = (sampleRate * WINDOW_MS / 1000).coerceAtLeast(1)
        val windowCount = (samples.size + windowSize - 1) / windowSize
        val energy = FloatArray(windowCount)
        for (w in 0 until windowCount) {
            val from = w * windowSize
            val to = minOf(from + windowSize, samples.size)
            var sum = 0.0
            for (i in from until to) {
                val s = samples[i] / 32768.0
                sum += s * s
            }
            energy[w] = (sum / (to - from)).toFloat()
            if (w % 50 == 0) onProgress(w / windowCount.toFloat() * 0.5f)
        }
        val sorted = energy.sorted()
        val p15 = sorted[(sorted.size * 0.15).toInt().coerceIn(0, sorted.size - 1)]
        // Floor keeps very quiet (but non-silent) audio from being cut.
        val threshold = maxOf(p15 * 3.0f, 1e-5f)

        val minWindows = (minSilenceMs / WINDOW_MS).toInt().coerceAtLeast(1)
        val result = mutableListOf<Pair<Long, Long>>()
        var runStart = -1
        for (w in energy.indices) {
            if (energy[w] < threshold) {
                if (runStart < 0) runStart = w
            } else {
                if (runStart >= 0 && w - runStart >= minWindows) {
                    result.add(silenceWindowToUs(runStart, w, windowSize, sampleRate))
                }
                runStart = -1
            }
            if (w % 50 == 0) onProgress(0.5f + w / windowCount.toFloat() * 0.5f)
        }
        if (runStart >= 0 && energy.size - runStart >= minWindows) {
            result.add(silenceWindowToUs(runStart, energy.size, windowSize, sampleRate))
        }
        onProgress(1f)
        return result
    }

    private fun silenceWindowToUs(
        fromW: Int, toW: Int, windowSize: Int, sampleRate: Int
    ): Pair<Long, Long> {
        val startUs = fromW.toLong() * windowSize * 1_000_000L / sampleRate
        val endUs = toW.toLong() * windowSize * 1_000_000L / sampleRate
        return startUs to endUs
    }
}
