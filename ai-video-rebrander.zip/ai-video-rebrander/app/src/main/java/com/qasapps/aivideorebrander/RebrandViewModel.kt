package com.qasapps.aivideorebrander

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.qasapps.aivideorebrander.data.EditStyle
import com.qasapps.aivideorebrander.data.RebrandOptions
import com.qasapps.aivideorebrander.data.VideoMeta
import com.qasapps.aivideorebrander.engine.VideoMetaReader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RebrandViewModel : ViewModel() {
    var inputUri by mutableStateOf<Uri?>(null)
        private set
    var meta by mutableStateOf<VideoMeta?>(null)
        private set
    var thumbnail by mutableStateOf<Bitmap?>(null)
        private set
    var options by mutableStateOf(RebrandOptions())
    var loadError by mutableStateOf<String?>(null)
        private set

    fun pickVideo(context: Context, uri: Uri) {
        inputUri = uri
        loadError = null
        try {
            // Persist access so re-exports keep working after process death.
            context.contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) { /* GetContent-style one-shot grant; still fine */ }
        try {
            meta = VideoMetaReader.read(context, uri)
            thumbnail = loadThumb(context, uri)
        } catch (e: Exception) {
            loadError = "Could not read that video: ${e.message}"
        }
    }

    fun chooseStyle(style: EditStyle) {
        options = RebrandOptions.defaultsFor(style)
    }

    private fun loadThumb(context: Context, uri: Uri): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.getFrameAtTime(500_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (_: Exception) {
            null
        } finally {
            r.release()
        }
    }

    /** Copies the exported preview file into Movies/AI Video Rebrander. */
    fun saveToGallery(context: Context, file: File): Result<Uri> = runCatching {
        val name = "Rebranded_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AI Video Rebrander")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val itemUri = context.contentResolver.insert(collection, values)
            ?: throw IllegalStateException("Could not create gallery entry.")
        context.contentResolver.openOutputStream(itemUri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw IllegalStateException("Could not write gallery file.")
        if (Build.VERSION.SDK_INT >= 29) {
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            context.contentResolver.update(itemUri, values, null, null)
        }
        itemUri
    }
}
