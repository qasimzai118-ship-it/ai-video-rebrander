# AI Video Rebrander — Android app

An Android app (Kotlin + Jetpack Compose) that picks a video from the phone and
automatically produces a re-edited MP4: smart scene cuts, silence removal,
animated zooms, color grades, dip-to-black transitions, on-device AI captions,
title/brand overlays, audio normalization, optional background music, and
9:16 / 16:9 / 1:1 export at 720p or 1080p.

**Video engine:** Jetpack Media3 Transformer (Apache 2.0) — no FFmpeg, no
server, no paid APIs.
**Captions:** Vosk on-device speech recognition (Apache 2.0). The small English
model (~40 MB) downloads once, on first use, with your consent; afterwards
everything works offline.

## Honest feature map

Nothing here is a fake button. Each feature maps to real code:

| Feature | Implementation |
|---|---|
| Smart scene detection | `engine/Analysis.kt` — 64-bin RGB histogram + chi-square distance between sampled frames, adaptive threshold. A classic CV heuristic, **not** a neural network; the UI calls it "scene detection", never "AI". |
| Automatic cuts | `engine/SilenceDetector.kt` — PCM RMS energy per 100 ms window, adaptive threshold; long silences are subtracted from scenes in `EditPlanner`. |
| Dynamic zoom | Animated `MatrixTransformation` per segment (smoothstep eased push-in / pull-out, stronger in Dynamic style). |
| Color grading | `Contrast` + `HslAdjustment` presets (cinematic warm / vivid) and `RgbFilter` grayscale (noir). |
| Transitions | Dip-to-black: a real 140 ms black clip (black H.264 + silent AAC, generated with `MediaCodec`/`MediaMuxer`) is interleaved between segments. |
| AI captions | Vosk `Recognizer` with word timings → grouped caption lines, burned in with `TextOverlay`. Segments are split at caption boundaries so each exported item shows exactly one line. Editable before export. |
| Text overlays | `TextOverlay` title card + watermark. |
| Audio | Custom `GainAudioProcessor` normalizes peak to 0.89; optional background music is mixed as a second Transformer sequence. |
| Aspect ratios | Center-`Crop` to 9:16 / 16:9 / 1:1, then `Presentation` scale to export height. |
| Export | H.264 + AAC MP4, 720p/1080p, via `Transformer` + `Composition`. |
| Long work | `ExportService` foreground service: progress notification, cancellation, survives rotation/backgrounding. Partial files are deleted on cancel. |
| Permissions | Only `POST_NOTIFICATIONS` (progress). Video/music access comes from the system file picker (`OpenDocument`) — no broad storage permission. Originals are never modified. |

## Build & install

Requirements: Android Studio (Ladybug or newer), JDK 17, Android SDK with
API 34.

1. Open this folder in Android Studio and let Gradle sync
   (or from a terminal with Gradle 8.7+: `gradle assembleDebug`).
2. Connect a phone with USB debugging, press **Run**.
   The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`
   (`Build > Build APK` also works).

First-run notes:
- Pick a video with the system picker; choose a style; tweak options;
  tap **Auto Re-Edit**.
- If captions are on, you'll be asked once to download the ~40 MB Vosk model
  (free, from alphacephei.com). Declining just skips captions — nothing breaks.
- Preview → uncheck scenes, edit caption text, change overlays → **Re-export**
  → **Save to phone** writes to `Movies/AI Video Rebrander`.

## Things to verify on a real device (author couldn't compile here)

This source was written against the published Media3 1.11.1 APIs but was
**not compiled or device-tested** (no Android SDK in the author's environment).
Before shipping, check:

- `Crop(left, right, top, bottom)` parameter order/semantics for your target
  aspect ratios — values are symmetric for center crops, but confirm visually.
- `StaticOverlaySettings` anchor signs: recent Media3 releases flipped overlay
  x/y anchoring; if captions/title/watermark land in the wrong corner, negate
  the anchor values in `VideoProcessor.buildEditedItem`.
- `TextOverlay` renders at its default text size — confirm readability at 720p.
- Background-music mixing relies on Transformer mixing audio from two
  `EditedMediaItemSequence`s; if a device errors here, the failure is surfaced
  with a clear message (music stays optional).
- Vosk model URL (`CaptionEngine.MODEL_URL`) — if it 404s, grab any 16 kHz
  Vosk model from https://alphacephei.com/vosk/models and update the constant.

## Project layout

```
app/src/main/java/com/qasapps/aivideorebrander/
  MainActivity.kt            NavHost (home → style → options → processing → preview)
  RebrandViewModel.kt        picked video, metadata, options, gallery save
  data/Models.kt             EditStyle, RebrandOptions, Scene, CaptionLine, EditPlan…
  engine/
    Analysis.kt              SceneDetector (histogram cuts) + SilenceDetector (RMS)
    PcmDecoder.kt            MediaCodec audio → mono PCM (+ 16 kHz resample)
    CaptionEngine.kt         Vosk download + on-device transcription
    EditPlanner.kt           scenes − silence − user toggles → keep segments
    VideoProcessor.kt        Media3 Composition: cuts, zoom, grade, overlays,
                             captions, transitions, audio, music, export
    ExportService.kt         foreground service: pipeline, progress, cancel
  ui/
    Theme.kt, Screens.kt     home / style / options
    WorkScreens.kt           processing (progress+cancel) / preview (adjust+save)
```

## License notes

- Media3, Jetpack Compose, Vosk, JNA: Apache License 2.0.
- No FFmpeg is used, so no GPL/LGPL obligations arise from the video engine.
- The app code itself is yours to license as you wish.
